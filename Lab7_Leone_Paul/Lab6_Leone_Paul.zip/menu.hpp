/***********************************************************************************************
 * Program Name: menu.hpp
 * Author: Paul Leone
 * Date: 8/1/2019
 * Description: This is the menu header file to display the menu options
 * *********************************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

void displayMenu();

#endif
